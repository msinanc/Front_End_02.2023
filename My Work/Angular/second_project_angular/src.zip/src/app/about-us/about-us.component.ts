import { Component } from '@angular/core';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent {
  title="About Us";
  description="Merhaba Ben Erhan Kaya. 33 Yaşındayım. Mekatronik Mühendisyim."
}
