import { Component } from "@angular/core";

@Component({
    selector:"header",
    templateUrl:"./header.html"
})
export class HeaderComponent{
    logoName="Product Managament";
}