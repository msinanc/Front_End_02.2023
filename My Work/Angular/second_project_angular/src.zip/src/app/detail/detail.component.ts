import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../models/Product';
import { ProductServicesService } from '../product-services.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit{
//http://localhost:4200/Detail/3

  @Input() product:Product | undefined;
  basketNumber=1;
  constructor(
    private productServices:ProductServicesService,
    private route:ActivatedRoute){}

    ngOnInit(): void {
      this.getProduct();
    }
    getProduct(): void{
      const id = this.route.snapshot.paramMap.get('id');
      this.productServices.getSingleProduct(Number(id))
      .subscribe(urun=>this.product=urun)
    } 

    minusProduct(){
      this.basketNumber--;
      
    }
    plusProduct(){
      this.basketNumber++;
    }
}

